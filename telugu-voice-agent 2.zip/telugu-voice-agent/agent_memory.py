# agent_memory.py

state = {
    "step": 0,
    "data": {}
}

QUESTIONS = [
    "మీ వయసు ఎంత?",
    "మీ వార్షిక ఆదాయం ఎంత?",
    "మీరు ఏ రాష్ట్రంలో ఉంటున్నారు?",
    "మీ లింగం ఏమిటి?"
]

def update_memory(text: str):
    global state

    if state["step"] == 0:
        state["data"]["age"] = text
    elif state["step"] == 1:
        state["data"]["income"] = text
    elif state["step"] == 2:
        state["data"]["state"] = text
    elif state["step"] == 3:
        state["data"]["gender"] = text

    state["step"] += 1


def get_next_question():
    if state["step"] < len(QUESTIONS):
        return QUESTIONS[state["step"]]
    return None


def is_complete():
    return state["step"] >= len(QUESTIONS)
