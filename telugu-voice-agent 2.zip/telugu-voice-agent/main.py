from fastapi import FastAPI, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse
import whisper
import tempfile

from agent_memory import update_memory, get_next_question
from tools import check_eligibility

app = FastAPI()
model = whisper.load_model("base")


@app.get("/", response_class=HTMLResponse)
def home():
    with open("index.html", "r", encoding="utf-8") as f:
        return f.read()


@app.post("/voice")
async def voice(audio: UploadFile):
    with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as f:
        f.write(await audio.read())
        audio_path = f.name

    result = model.transcribe(audio_path, language="te")
    text = result["text"]

    update_memory(text)

    next_q = get_next_question()
    if next_q:
        return JSONResponse({"reply": next_q})

    schemes = check_eligibility()
    return JSONResponse({
        "reply": "మీకు సరిపడే పథకాలు: " + ", ".join(schemes)
    })


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
@app.post("/voice")
async def voice(audio: UploadFile):
    with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as f:
        f.write(await audio.read())
        path = f.name

    result = model.transcribe(path, language="te")
    text = result["text"]

    update_memory(text)

    next_q = get_next_question()
    if next_q:
        return JSONResponse({"reply": next_q})

    schemes = check_eligibility()
    return JSONResponse({
        "reply": "మీకు సరిపడే పథకాలు: " + ", ".join(schemes)
    })
