# tools.py
import json

def check_eligibility():
    with open("schemes.json", "r", encoding="utf-8") as f:
        data = json.load(f)
    return [s["name"] for s in data]


